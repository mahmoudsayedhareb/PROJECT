﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FIFO.Project1
{
    internal class HandyMen : Employee
    {
        public int HardShip {  get; set; }

        protected override decimal CalculateGrossPay()
        {
            return base.CalculateGrossPay()+HardShip;
        }
        public override void print()
        {
            base.print();
            Console.WriteLine($"HardShip: {HardShip} \n");
        }

    }
}
