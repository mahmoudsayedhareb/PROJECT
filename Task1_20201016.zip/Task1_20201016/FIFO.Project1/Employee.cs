﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FIFO.Project1
{
    internal abstract class Employee
    {

        public string Id {  get; set; }
        public string FName { get; set; }
        public string LName {  get; set; }
        public decimal HourlyRate {  get; set; }
        public int ExpectedHours {  get; set; }
        public int LoggedHours { get; set; }

        protected decimal CalculateBasicSalary()
        {
            return LoggedHours > ExpectedHours ? ExpectedHours * HourlyRate : LoggedHours * HourlyRate; 


        }

        protected decimal CalculateOverTime()
        {
            return LoggedHours > ExpectedHours ? (LoggedHours - ExpectedHours) * HR.OverTimeRate * HourlyRate : 0;

        }
        protected virtual decimal CalculateGrossPay()
        {
            return CalculateBasicSalary() + CalculateOverTime();
        }
        protected decimal TaxAmount()
        {
            return CalculateGrossPay() * HR.TaxAmountRate;
        }
        protected decimal NetSalary()
        {
            return CalculateGrossPay() - TaxAmount();
        }
        public virtual void print()
        {
            Console.Write($"Employee: {FName} {LName} \n" +
                $"ID: {Id}\n" +
                $"HoursLogged: {LoggedHours}\n" +
                $"Hourly Rate: {HourlyRate}\n" +
                $"BasicSalary: {CalculateBasicSalary()}\n" +
                $"OverTime ({HR.OverTimeRate}X): {CalculateOverTime()}\n" +
                $"GrossPay: {CalculateGrossPay()}\n" +
                $"TaxAmount: {TaxAmount()}\n" +
                $"NetSalary: {NetSalary()} \n"



                );
        }
    }
}
