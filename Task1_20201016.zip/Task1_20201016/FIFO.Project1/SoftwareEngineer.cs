﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Channels;

namespace FIFO.Project1
{
    internal class SoftwareEngineer:Employee
    {
        public int TrainingAllowence { get; set; }
        public int StoryPointCompeleted {  get; set; }

        protected override decimal CalculateGrossPay()
        {
            return base.CalculateGrossPay() + TrainingAllowence + (StoryPointCompeleted >= HR.StoryPointCompleted ?HR.Bonus : 0);
        }

        public override void print()
        {
            base.print();
            Console.WriteLine($"TrainingAllowence: {TrainingAllowence} \n"+
                $"StoryPointCompeleted: {StoryPointCompeleted} \n"
                );
        }


    }
}
