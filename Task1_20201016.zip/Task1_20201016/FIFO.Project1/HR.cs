﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FIFO.Project1
{
    internal class HR
    {
        public const decimal OverTimeRate = 1.5m;

        public const decimal TaxAmountRate = 0.1m;
        public const decimal Commission = 0.05m;
        public const decimal StoryPointCompleted = 8m;

        public const decimal Bonus = 40m;

    }

}
