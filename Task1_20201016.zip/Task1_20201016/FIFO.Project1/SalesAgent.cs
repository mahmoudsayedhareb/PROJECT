﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FIFO.Project1
{
    internal class SalesAgent : Employee
    {
        public int TotalSales {  get; set; }

        protected override decimal CalculateGrossPay()
        {
            return base.CalculateGrossPay() + (TotalSales * HR.Commission);
        }
        public override void print()
        {
            base.print();
            Console.WriteLine($"TotalSales: {TotalSales} \n");
        }

    }
}
