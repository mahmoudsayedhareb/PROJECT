﻿
using FIFO.Project1;
using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Runtime.InteropServices;
using System.Security.Cryptography;



class Program
{

    static void Main(string[] args)
    {
       
        List<Employee> emps = new()
        {
          new Manager{
            Id = "1001",
            FName = "Ahmed",
            LName = "Salem",
            HourlyRate = 10,
            ExpectedHours = 40,
            LoggedHours=40,
            Allowence=100
          },
          new SalesAgent
          {
               Id = "100",
            FName = "Reem",
            LName = "Abdallah",
            HourlyRate = 10,
            ExpectedHours = 40,
            LoggedHours=45,
            TotalSales = 10000
          },
          new HandyMen
          {
               Id = "1003",
            FName = "Salah",
            LName = "Adel",
            HourlyRate = 5,
            ExpectedHours = 40,
            LoggedHours=65,
            HardShip = 75
          },
          new SoftwareEngineer
          {
               Id = "1004",
            FName = "Samaa",
            LName = "Eslam",
            HourlyRate = 10,
            ExpectedHours = 40,
            LoggedHours=40,
            TrainingAllowence = 50,
            StoryPointCompeleted = 8
          }

        };

        foreach (var emp in emps)
        {
            Console.WriteLine($"---------------------{emp.GetType()}-------------------------------");
            emp.print();
           
        }

        


      



    Console.ReadKey();

        }
  

   

}

abstract class Veichle
{
    protected string name;
    protected string brand;
    protected int model;

    protected Veichle(string name ,string brand,int model)
    {
        this.name = name;
        this.brand = brand;
        this.model = model;
    }

    public void move()
    {
        Console.WriteLine("Moving...");
    }

}

class Wheel
{
    string wname;
    string wbrand;
    int wprice;
    public Wheel(string name,string brand,int price)
    {
        this.wname = name;
        this.wbrand = brand;
        this.wprice = price;
        

    }
    public void print()
    {
        Console.WriteLine(wname + " " + wbrand + " " + wprice);
    }
}

 class Car : Veichle
{
    Wheel wheel;
    public Car(string name, string brand, int model):base(name,brand,model)
    {
        wheel = new Wheel("xyw", "abc", 1500);
    }
    public void info()
    {
       wheel.print();
    }   
}



/*
         int N = Convert.ToInt32(Console.ReadLine());
        int M = Convert.ToInt32(Console.ReadLine());

        int[,] matrix = new int[N, M];

        for(int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                matrix[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        int position_i = Convert.ToInt32(Console.ReadLine());
        int position_j = Convert.ToInt32(Console.ReadLine());
        int no_rows = Convert.ToInt32(Console.ReadLine());
        int no_cols = Convert.ToInt32(Console.ReadLine());

        int sum_primes = 0;
        for(int i = 0; i < no_rows; i++)
        {
            for(int j = 0; j < no_cols; j++)
            {
                int number = matrix[i + position_i, j + position_j];
                if(is_prime(number))
                    sum_primes++;
            }
        }

        Console.WriteLine(sum_primes);



      static bool is_prime(int n)
    {
        for(int i = 2; i < n; i++)
        {
            if( n % i == 0)
                return false;
        }
        return true;
    }
 
 */

