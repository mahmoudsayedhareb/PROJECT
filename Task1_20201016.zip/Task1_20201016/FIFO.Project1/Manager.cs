﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FIFO.Project1
{
    internal class Manager : Employee
    {
        public int Allowence {  get; set; }

        protected override decimal CalculateGrossPay()
        {
            return base.CalculateGrossPay() + Allowence;
        }

        public override void print()
        {
            base.print();
            Console.WriteLine($"Allowence: {Allowence} \n");
        }


    }
}
