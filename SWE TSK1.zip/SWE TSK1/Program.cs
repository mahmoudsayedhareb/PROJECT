﻿using System;
using ConsoleApp1;

ATM myAtm = new ATM();
bool running = true;

while (running)
{
    Console.WriteLine("\n--- ATM Menu ---");
    Console.WriteLine("1. Check Balance");
    Console.WriteLine("2. Deposit");
    Console.WriteLine("3. Withdraw");
    Console.WriteLine("4. Exit");
    Console.Write("Select an option: ");

    string choice = Console.ReadLine() ?? string.Empty;

    switch (choice)
    {
        case "1":
            Console.WriteLine($"Current Balance: {myAtm.GetBalance()}");
            break;
        case "2":
            Console.Write("Enter deposit amount: ");
            string? depositInput = Console.ReadLine();
            if (!decimal.TryParse(depositInput, out decimal dAmount))
            {
                Console.WriteLine("Invalid amount.");
                break;
            }
            if (dAmount < 0)
            {
                Console.WriteLine("Transaction cannot be made.");
                break;
            }
            myAtm.Deposit(dAmount);
            break;
        case "3":
            Console.Write("Enter withdrawal amount: ");
            string? withdrawInput = Console.ReadLine();
            if (!decimal.TryParse(withdrawInput, out decimal wAmount))
            {
                Console.WriteLine("Invalid amount.");
                break;
            }
            myAtm.Withdraw(wAmount);
            break;
        case "4":
            Console.WriteLine("Goodbye.");
            running = false;
            break;
        default:
            Console.WriteLine("Invalid option.");
            break;
    }
}