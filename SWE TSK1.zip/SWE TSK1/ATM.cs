using System.Diagnostics;

namespace ConsoleApp1
{
	   class ATM
	{
		private decimal balance;
		
		public void Deposit(decimal amount)
		{
			balance += amount;
		}
		public void Withdraw(decimal amount)
		{
			if (amount > balance)
			{
				Console.WriteLine ("Insufficient funds.");
				return;					
			}
			balance -= amount;
		}

		public decimal GetBalance()
		{
			return balance;
		}



	}
}